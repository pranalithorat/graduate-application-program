package gapp.model.dao;

import java.util.List;

import gapp.model.Application;
import gapp.model.Department;
import gapp.model.User;

public interface ApplicationDao {

	Department getDeptId(String dept_name);

	List<Application> getTerms(Integer dept_Id, String term);

}
