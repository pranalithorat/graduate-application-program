
    create table additionalfields (
        addFieldId int4 not null,
        fieldName varchar(255),
        fieldType varchar(255),
        fileValue bytea,
        isRequired boolean,
        numberValue int4,
        textValue varchar(255),
        application_appId int4,
        dept_deptId int4,
        primary key (addFieldId)
    );

    create table applicationStatuses (
        AppStatusId int4 not null,
        comments varchar(255),
        dateChanged timestamp,
        appId_appId int4,
        status_statusId int4,
        updatedBy_id int4,
        primary key (AppStatusId)
    );

    create table applications (
        appId int4 not null,
        term varchar(255),
        transcript bytea,
        department_deptId int4,
        program_prgmId int4,
        status_statusId int4,
        user_id int4,
        primary key (appId)
    );

    create table departments (
        deptId int4 not null,
        deptName varchar(255),
        primary key (deptId)
    );

    create table educationalbackgrounds (
        edBckId int4 not null,
        degreeEarned varchar(255),
        degreeMajor varchar(255),
        gpa float8,
        timeAttended timestamp,
        univName varchar(255),
        applicationId_appId int4,
        user_id int4,
        primary key (edBckId)
    );

    create table materials (
        Id int4 not null,
        material bytea,
        materialName varchar(255),
        appli_appId int4,
        user_id int4,
        primary key (Id)
    );

    create table programs (
        prgmId int4 not null,
        programName varchar(255),
        dept_deptId int4,
        primary key (prgmId)
    );

    create table statuses (
        statusId int4 not null,
        statusDescription varchar(255),
        statusName varchar(255),
        appStatus_AppStatusId int4,
        primary key (statusId)
    );

    create table users (
        id int4 not null,
        cin varchar(255),
        citizenship varchar(255),
        dob timestamp,
        email varchar(255) not null,
        fname varchar(255),
        gender varchar(255),
        greScore int4,
        isAdmin boolean not null,
        isInternationalStudent boolean,
        isStaff boolean not null,
        isStudent boolean not null,
        lname varchar(255),
        password varchar(255),
        phoneNo int8,
        tofelScore int4,
        transcript bytea,
        primary key (id)
    );

    alter table users 
        add constraint UK_6dotkott2kjsp8vw4d0m25fb7 unique (email);

    alter table additionalfields 
        add constraint FK_hse64wqnu69egpdm13j5959n3 
        foreign key (application_appId) 
        references applications;

    alter table additionalfields 
        add constraint FK_pn7sk076jpbbxdnjp15kc0scx 
        foreign key (dept_deptId) 
        references departments;

    alter table applicationStatuses 
        add constraint FK_9fbba5os8m22ikw95hjp3wfc 
        foreign key (appId_appId) 
        references applications;

    alter table applicationStatuses 
        add constraint FK_lg6ye7m9t4pdypv31630kgn40 
        foreign key (status_statusId) 
        references statuses;

    alter table applicationStatuses 
        add constraint FK_sb4792d5ll69h5w4153padain 
        foreign key (updatedBy_id) 
        references users;

    alter table applications 
        add constraint FK_jkmhre0l44lj4ua89l9s01s9i 
        foreign key (department_deptId) 
        references departments;

    alter table applications 
        add constraint FK_j8ibfh51fj4yaj51hrkcgeivj 
        foreign key (program_prgmId) 
        references programs;

    alter table applications 
        add constraint FK_m4tb59c1ittrlp79yskni55ul 
        foreign key (status_statusId) 
        references statuses;

    alter table applications 
        add constraint FK_il296b7i4a8es7mgs2a79gl8o 
        foreign key (user_id) 
        references users;

    alter table educationalbackgrounds 
        add constraint FK_fd2xnxr7mm5vtcdr0004gcmjs 
        foreign key (applicationId_appId) 
        references applications;

    alter table educationalbackgrounds 
        add constraint FK_irwh1boblcdmc289vsr00ioaw 
        foreign key (user_id) 
        references users;

    alter table materials 
        add constraint FK_hdqlmgqsyudinaypwntif8h5p 
        foreign key (appli_appId) 
        references applications;

    alter table materials 
        add constraint FK_c0fxt68sv6ggmpdsqt3vk07n1 
        foreign key (user_id) 
        references users;

    alter table programs 
        add constraint FK_nukuqs5hc9dxrp4b4f9mvn4yt 
        foreign key (dept_deptId) 
        references departments;

    alter table statuses 
        add constraint FK_es69sq44x9sn1r8lp4s2oihk1 
        foreign key (appStatus_AppStatusId) 
        references applicationStatuses;

    create sequence hibernate_sequence;

    
-- 1    
insert into users values(1,null,'American',null,'admin@localhost.localdomain','Tom','male',null,true,null,false,false,'Hardy','abcd',null,null,null);
insert into users values(2,null,'African',null,'staff1@localhost.localdomain','James','male',null,false,null,true,false,'Pitt','1234',null,null,null);
insert into users values(3,null,'Indian',null,'staff2@localhost.localdomain','Peter','male',null,false,null,true,false,'Dsouza','xyz',null,null,null);
insert into users values(4,'123456789','Indian',null,'student1@localhost.localdomain','Rachel','female',304,false,null,false,true,'Green','6789',100,null,null);
insert into users values(5,'13466789','Russian',null,'student2@localhost.localdomain','Pheobe','female',307,false,null,false,true,'Buffay','new',104,null,null);

-- 2
insert into departments values(1,'Accounting Department');
insert into departments values(2,'Computer Science');
insert into programs values(1,'MS in Accounting',1);
insert into programs values(2,'MS in Computer Science',2);
insert into additionalfields values(1,'GMAT','Number',null,true,null,null,null,1);

-- 3
insert into applications values(1,'Fall 2016',null,1,null,null,1);
