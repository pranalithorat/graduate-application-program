package gapp.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "educationalbackgrounds")
public class EducationalBackground implements Serializable {

	@Id
	@GeneratedValue
	private Integer edBckId;// id

	private String univName;

	private Date timeAttended;

	private String degreeEarned;

	private String degreeMajor;

	private Double gpa;

	@ManyToOne
	private User user;

	@ManyToOne
	private Application applicationId;

	public EducationalBackground() {

	}

	public Integer getEdBckId() {
		return edBckId;
	}

	public void setEdBckId(Integer edBckId) {
		this.edBckId = edBckId;
	}

	public String getUnivName() {
		return univName;
	}

	public void setUnivName(String univName) {
		this.univName = univName;
	}

	public Date getTimeAttended() {
		return timeAttended;
	}

	public void setTimeAttended(Date timeAttended) {
		this.timeAttended = timeAttended;
	}

	public String getDegreeEarned() {
		return degreeEarned;
	}

	public void setDegreeEarned(String degreeEarned) {
		this.degreeEarned = degreeEarned;
	}

	public Double getGpa() {
		return gpa;
	}

	public void setGpa(Double gpa) {
		this.gpa = gpa;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Application getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Application applicationId) {
		this.applicationId = applicationId;
	}

	public String getDegreeMajor() {
		return degreeMajor;
	}

	public void setDegreeMajor(String degreeMajor) {
		this.degreeMajor = degreeMajor;
	}

}
