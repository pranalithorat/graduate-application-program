package gapp.model.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gapp.model.Application;
import gapp.model.Department;
import gapp.model.dao.ApplicationDao;
import gapp.model.dao.DepartmentDao;

@Repository
public class ApplicationDaoImpl implements ApplicationDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	DepartmentDao deptDao;

	@Override
	public Department getDeptId(String deptname) {
		return entityManager.createQuery("from Department where deptName = '" + deptname + "'", Department.class)
				.getSingleResult();
	}

	@Override
	public List<Application> getTerms(Integer dept_Id, String term) {

		return entityManager
				.createQuery("from Application where department = '" + dept_Id + "' and term = '" + term + "' ",
						Application.class)
				.getResultList();
	}

}
