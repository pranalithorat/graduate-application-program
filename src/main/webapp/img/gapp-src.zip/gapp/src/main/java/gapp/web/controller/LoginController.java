package gapp.web.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import gapp.model.User;
import gapp.model.dao.UserDao;
import gapp.web.validator.UserValidator;

@Controller
@SessionAttributes("user")
public class LoginController {
	
	@Autowired
    private UserDao userDao;
   
    
    @Autowired
    UserValidator userValidator;
    
    @RequestMapping(value = "/user/login.html", method = RequestMethod.GET)
    public String add( ModelMap models )
    {
    	models.put( "user", new User() );
    	
    	return "user/login";
		
    }
    
    @RequestMapping(value = "/user/login.html", method = RequestMethod.POST)
    public String login( @ModelAttribute User user,BindingResult bindingResult,HttpSession session)
    {
    	
        	User u=userDao.checkLogin(user, session);
        	
        	if(u!=null)
        	{
        		if(u.isAdmin()==true)
        		{
        			return "user/admin";
        		}
        		if(u.isStaff()==true)
        		{
        			return "user/staff";
        		}
        		if(u.isStudent()==true)
        		{
        			return "user/student";
        		}

        		return "user/login";
        	}
        	return null;
       
    }
    
    @RequestMapping("/user/logout.html")
    public String logout(ModelMap models,HttpSession session){
    	
    	
    	session.invalidate();
    	return "redirect:/user/login.html";
    }
	

}
