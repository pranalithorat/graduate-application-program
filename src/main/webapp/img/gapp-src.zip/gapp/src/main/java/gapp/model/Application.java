package gapp.model;

import java.io.File;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "applications")
public class Application implements Serializable {

	@Id
	@GeneratedValue
	private Integer appId;
	
	@ManyToOne
	private User user;
	

	@OneToOne
	private Status status;

	@ManyToOne
	private Program program;

	private File transcript;

	private String term;

	@ManyToOne
	private Department department;


	@OneToMany(mappedBy = "applicationId")
	private List<EducationalBackground> education;

	@OneToMany(mappedBy = "application")
	private List<AdditionalField> additionalFields;

	@OneToMany(mappedBy = "appli")
	private List<AdditionalApplicationMaterial> additionalMaterial;

	public Program getProgram() {
		return program;
	}

	public void setProgram(Program program) {
		this.program = program;
	}

	public List<AdditionalApplicationMaterial> getAdditionalMaterial() {
		return additionalMaterial;
	}

	public void setAdditionalMaterial(List<AdditionalApplicationMaterial> additionalMaterial) {
		this.additionalMaterial = additionalMaterial;
	}

	public Integer getAppId() {
		return appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<EducationalBackground> getEducation() {
		return education;
	}

	public void setEducation(List<EducationalBackground> education) {
		this.education = education;
	}

	public List<AdditionalField> getAdditionalFields() {
		return additionalFields;
	}

	public void setAdditionalFields(List<AdditionalField> additionalFields) {
		this.additionalFields = additionalFields;
	}

	public File getTranscript() {
		return transcript;
	}

	public void setTranscript(File transcript) {
		this.transcript = transcript;
	}

}
