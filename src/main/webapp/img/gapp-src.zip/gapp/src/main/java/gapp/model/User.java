package gapp.model;

import java.io.File;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User implements Serializable {

	@Id
	@GeneratedValue
	private Integer id;

	private String fname;
	
	private String lname;

	@Column(nullable = false, unique = true)
	private String email;

	private String password;
	
	private boolean isAdmin;
	
	private boolean isStaff;
	
	private boolean isStudent;
	
	private String cin;

	private Long phoneNo;

	private String gender;

	private Date dob;

	private String citizenship;
	
	private Integer tofelScore;

	private Integer greScore;

	private File transcript;

	private Boolean isInternationalStudent;
	
	@OneToMany(mappedBy = "user")
	private List<Application> application;
	
	@OneToMany(mappedBy = "user")
	private List<AdditionalApplicationMaterial> material;
	
	
	
	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isStaff() {
		return isStaff;
	}

	public void setStaff(boolean isStaff) {
		this.isStaff = isStaff;
	}

	public boolean isStudent() {
		return isStudent;
	}

	public void setStudent(boolean isStudent) {
		this.isStudent = isStudent;
	}

	public String getCin() {
		return cin;
	}

	public void setCin(String cin) {
		this.cin = cin;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getCitizenship() {
		return citizenship;
	}

	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}

	public Integer getTofelScore() {
		return tofelScore;
	}

	public void setTofelScore(Integer tofelScore) {
		this.tofelScore = tofelScore;
	}

	public Integer getGreScore() {
		return greScore;
	}

	public void setGreScore(Integer greScore) {
		this.greScore = greScore;
	}

	public File getTranscript() {
		return transcript;
	}

	public void setTranscript(File transcript) {
		this.transcript = transcript;
	}

	public Boolean getIsInternationalStudent() {
		return isInternationalStudent;
	}

	public void setIsInternationalStudent(Boolean isInternationalStudent) {
		this.isInternationalStudent = isInternationalStudent;
	}

	public List<Application> getApplication() {
		return application;
	}

	public void setApplication(List<Application> application) {
		this.application = application;
	}

	public List<EducationalBackground> getEdBckgrnd() {
		return edBckgrnd;
	}

	public void setEdBckgrnd(List<EducationalBackground> edBckgrnd) {
		this.edBckgrnd = edBckgrnd;
	}

	public void setMaterial(List<AdditionalApplicationMaterial> material) {
		this.material = material;
	}

	@OneToMany(mappedBy = "user")
	private List<EducationalBackground> edBckgrnd;

	
	public User() {
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public List<AdditionalApplicationMaterial> getMaterial() {
		return material;
	}

	

}